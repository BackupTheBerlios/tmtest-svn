struct test;
int printvar(struct test *test, FILE *fp, const char *varname);
