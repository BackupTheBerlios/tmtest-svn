char * rel2abs(const char *path, const char *base, char *result, const size_t size);

