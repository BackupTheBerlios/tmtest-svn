struct test;
int file_exists(char *path);
int printvar(struct test *test, FILE *fp, const char *varname);
